# 1. Have Node.js installed
Pick v22.11.0 (LTS)
[Node.js](https://nodejs.org/en)

# 2. Clone the git repo
Or run this in your terminal: `git clone https://github.com/teeverc/cmpt272project`

# 3. Install dependencies
Run this in your terminal: `npm install`

# 4. Start the development server
Run this in your terminal: `npm run dev`

# 5. Start coding
